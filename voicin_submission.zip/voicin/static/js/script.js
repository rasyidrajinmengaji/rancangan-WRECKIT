document.addEventListener('DOMContentLoaded', () => {
    const uploadForm = document.getElementById('uploadForm');
    const fileInput = document.getElementById('fileInput');
    const fileName = document.getElementById('fileName');
    const btnUpload = document.getElementById('btnUpload');
    const btnRecord = document.getElementById('btnRecord');
    const btnStop = document.getElementById('btnStop');
    const resultCard = document.getElementById('resultCard');
    const loading = document.getElementById('loading');
    const resultLabel = document.getElementById('resultLabel');
    const confidenceText = document.getElementById('confidenceText');
    const resultIcon = document.getElementById('resultIcon');
    const confidenceBar = document.getElementById('confidenceBar');
    const audioPlayback = document.getElementById('audioPlayback');
    
    // Status box for notifications
    const statusBox = document.createElement('div');
    statusBox.className = 'status-message';
    statusBox.style.display = 'none';
    resultCard.parentNode.insertBefore(statusBox, resultCard);

    let wavRecorder;
    let stream;

    const showStatus = (message, type = 'info') => {
        statusBox.textContent = message;
        statusBox.className = `status-message ${type}`;
        statusBox.style.display = 'block';
    };

    const hideStatus = () => {
        statusBox.textContent = '';
        statusBox.style.display = 'none';
    };

    const setResult = (hasil, confidence) => {
        resultLabel.textContent = hasil;
        confidenceText.textContent = 'Confidence: ' + confidence + '%';
        resultCard.style.display = 'block';
        resultCard.className = 'result-card';
        resultCard.classList.add(hasil === 'Original Voice' ? 'original' : 'ai');
        resultIcon.className = hasil === 'Original Voice' ? 'fa-solid fa-circle-check' : 'fa-solid fa-circle-xmark';
        confidenceBar.style.width = confidence + '%';
    };

    const resetResult = () => {
        resultCard.style.display = 'none';
        resultCard.className = 'result-card';
        confidenceBar.style.width = '0%';
        audioPlayback.style.display = 'none';
        audioPlayback.src = '';
    };

    // File Upload input listener
    fileInput.addEventListener('change', () => {
        const file = fileInput.files[0];
        if (file) {
            fileName.textContent = file.name;
            btnUpload.disabled = false;
            hideStatus();
        } else {
            fileName.textContent = '';
            btnUpload.disabled = true;
        }
    });

    // Form Upload submit listener
    uploadForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const file = fileInput.files[0];
        if (!file) {
            showStatus('Pilih file audio terlebih dahulu.', 'error');
            return;
        }

        const formData = new FormData();
        formData.append('audio', file);

        loading.style.display = 'block';
        hideStatus();
        resetResult();

        try {
            const response = await fetch('/upload', {
                method: 'POST',
                body: formData
            });
            const data = await response.json();
            loading.style.display = 'none';

            if (response.ok) {
                setResult(data.hasil, data.confidence);
                showStatus('Analisis selesai.', 'success');
            } else {
                showStatus(data.error || 'Gagal menganalisis audio.', 'error');
            }
        } catch (error) {
            loading.style.display = 'none';
            showStatus('Gagal mengirim file. Periksa koneksi atau format file.', 'error');
        }
    });

    // WAV Recorder implementation using Web Audio API
    class WAVRecorder {
        constructor(stream) {
            this.stream = stream;
            this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
            this.input = this.audioContext.createMediaStreamSource(stream);
            // Use ScriptProcessorNode (mono channel, buffer size 4096)
            this.processor = this.audioContext.createScriptProcessor(4096, 1, 1);
            this.recording = false;
            this.leftchannel = [];
            this.recordingLength = 0;

            this.processor.onaudioprocess = (e) => {
                if (!this.recording) return;
                const left = e.inputBuffer.getChannelData(0);
                this.leftchannel.push(new Float32Array(left));
                this.recordingLength += left.length;
            };
        }

        start() {
            this.leftchannel = [];
            this.recordingLength = 0;
            this.recording = true;
            this.input.connect(this.processor);
            this.processor.connect(this.audioContext.destination);
        }

        stop() {
            this.recording = false;
            this.input.disconnect();
            this.processor.disconnect();

            // Merge PCM buffers
            const leftBuffer = this.mergeBuffers(this.leftchannel, this.recordingLength);

            // Create WAV binary format
            const buffer = new ArrayBuffer(44 + this.recordingLength * 2);
            const view = new DataView(buffer);

            // Write WAV header
            this.writeString(view, 0, 'RIFF');
            view.setUint32(4, 36 + this.recordingLength * 2, true);
            this.writeString(view, 8, 'WAVE');
            this.writeString(view, 12, 'fmt ');
            view.setUint32(16, 16, true);
            view.setUint16(20, 1, true); // PCM format
            view.setUint16(22, 1, true); // Mono channel
            const sampleRate = this.audioContext.sampleRate;
            view.setUint32(24, sampleRate, true);
            view.setUint32(28, sampleRate * 2, true); // Byte rate
            view.setUint16(32, 2, true); // Block align
            view.setUint16(34, 16, true); // Bits per sample
            this.writeString(view, 36, 'data');
            view.setUint32(40, this.recordingLength * 2, true);

            // Write PCM audio samples
            this.floatTo16BitPCM(view, 44, leftBuffer);

            return new Blob([view], { type: 'audio/wav' });
        }

        mergeBuffers(channelBuffer, recordingLength) {
            const result = new Float32Array(recordingLength);
            let offset = 0;
            for (let i = 0; i < channelBuffer.length; i++) {
                result.set(channelBuffer[i], offset);
                offset += channelBuffer[i].length;
            }
            return result;
        }

        writeString(view, offset, string) {
            for (let i = 0; i < string.length; i++) {
                view.setUint8(offset + i, string.charCodeAt(i));
            }
        }

        floatTo16BitPCM(output, offset, input) {
            for (let i = 0; i < input.length; i++, offset += 2) {
                let s = Math.max(-1, Math.min(1, input[i]));
                output.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
            }
        }

        async close() {
            if (this.audioContext) {
                await this.audioContext.close();
            }
        }
    }

    // Record button handler
    btnRecord.addEventListener('click', async () => {
        // Handle insecure context warning
        if (!window.isSecureContext && window.location.hostname !== 'localhost' && window.location.hostname !== '127.0.0.1') {
            showStatus('Akses mikrofon memerlukan koneksi aman (HTTPS atau localhost). Silakan gunakan http://localhost:5000 atau konfigurasikan HTTPS.', 'error');
            return;
        }

        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            showStatus('Browser Anda tidak mendukung akses mikrofon.', 'error');
            return;
        }

        try {
            showStatus('Meminta izin mikrofon...', 'info');
            stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            
            wavRecorder = new WAVRecorder(stream);
            wavRecorder.start();

            btnRecord.disabled = true;
            btnStop.disabled = false;
            showStatus('Rekaman sedang berjalan...', 'info');
            resetResult();
        } catch (err) {
            showStatus('Tidak bisa mengakses mikrofon. Izinkan akses mikrofon dan coba lagi.', 'error');
            console.error('Microphone access error:', err);
        }
    });

    // Stop recording button handler
    btnStop.addEventListener('click', async () => {
        if (wavRecorder && wavRecorder.recording) {
            const wavBlob = wavRecorder.stop();
            btnRecord.disabled = false;
            btnStop.disabled = true;
            showStatus('Memproses rekaman...', 'info');

            // Playback recording locally
            const audioUrl = URL.createObjectURL(wavBlob);
            audioPlayback.src = audioUrl;
            audioPlayback.style.display = 'block';

            const formData = new FormData();
            formData.append('audio', wavBlob, 'recording.wav');

            loading.style.display = 'block';
            hideStatus();

            try {
                const response = await fetch('/record', {
                    method: 'POST',
                    body: formData
                });
                const data = await response.json();
                loading.style.display = 'none';

                if (response.ok) {
                    setResult(data.hasil, data.confidence);
                    showStatus('Rekaman berhasil dianalisis.', 'success');
                } else {
                    showStatus(data.error || 'Gagal menganalisis rekaman.', 'error');
                }
            } catch (error) {
                loading.style.display = 'none';
                showStatus('Gagal mengirim rekaman. Coba lagi.', 'error');
            }

            // Stop all audio tracks in the stream
            if (stream) {
                stream.getTracks().forEach(track => track.stop());
            }
            await wavRecorder.close();
        }
    });
});
