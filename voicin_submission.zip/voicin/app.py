# app.py
# ==========================================
# File utama aplikasi VOICIN (Flask)
# Berisi routing halaman & logic upload/record
# ==========================================

from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
import sqlite3
import os
from datetime import datetime
from werkzeug.utils import secure_filename

# Import fungsi AI (akan dibuat di model.py pada tahap 7)
from model import predict_voice

# ------------------------------------------
# KONFIGURASI DASAR
# ------------------------------------------
app = Flask(__name__)
CORS(app)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_FOLDER = os.path.join(BASE_DIR, 'uploads')
ALLOWED_EXTENSIONS = {'wav', 'mp3', 'webm', 'm4a', 'ogg'}
DATABASE = os.path.join(BASE_DIR, 'database.db')

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Pastikan folder uploads ada
os.makedirs(UPLOAD_FOLDER, exist_ok=True)


# ------------------------------------------
# FUNGSI DATABASE
# ------------------------------------------
def init_db():
    """Membuat tabel history jika belum ada. Dipanggil sekali saat app start."""
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            filename TEXT NOT NULL,
            tanggal TEXT NOT NULL,
            hasil TEXT NOT NULL,
            confidence REAL NOT NULL
        )
    ''')
    conn.commit()
    conn.close()


def simpan_history(filename, hasil, confidence):
    """Menyimpan satu baris hasil deteksi ke database."""
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    tanggal = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    cursor.execute(
        'INSERT INTO history (filename, tanggal, hasil, confidence) VALUES (?, ?, ?, ?)',
        (filename, tanggal, hasil, confidence)
    )
    conn.commit()
    conn.close()


def ambil_semua_history():
    """Mengambil semua data history, terbaru di atas."""
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute('SELECT filename, tanggal, hasil, confidence FROM history ORDER BY id DESC')
    data = cursor.fetchall()
    conn.close()
    return data


def allowed_file(filename):
    """Cek apakah ekstensi file diizinkan."""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def get_audio_extension(filename, content_type=None):
    """Tentukan ekstensi yang aman untuk file audio."""
    if not filename:
        return None

    ext = filename.rsplit('.', 1)[-1].lower()
    if ext in ALLOWED_EXTENSIONS:
        return f'.{ext}'

    mime_map = {
        'audio/wav': '.wav',
        'audio/x-wav': '.wav',
        'audio/mpeg': '.mp3',
        'audio/mp3': '.mp3',
        'audio/webm': '.webm',
        'audio/mp4': '.m4a',
        'audio/ogg': '.ogg',
    }
    if content_type and content_type.lower() in mime_map:
        return mime_map[content_type.lower()]
    return None


# ------------------------------------------
# ROUTE HALAMAN (VIEW)
# ------------------------------------------
@app.route('/')
def index():
    """Halaman utama: berisi menu Record & Upload."""
    return render_template('index.html')


@app.route('/about')
def about():
    """Halaman About VOICIN."""
    return render_template('about.html')


@app.route('/history')
def history():
    """Halaman riwayat hasil deteksi (tabel)."""
    data = ambil_semua_history()
    return render_template('history.html', data=data)


@app.route('/api/history')
def api_history():
    """Mengembalikan data history dalam format JSON."""
    data = ambil_semua_history()
    formatted_data = []
    for row in data:
        formatted_data.append({
            'filename': row[0],
            'tanggal': row[1],
            'hasil': row[2],
            'confidence': row[3]
        })
    return jsonify(formatted_data)


# ------------------------------------------
# ROUTE PROSES AUDIO (UPLOAD)
# ------------------------------------------
@app.route('/upload', methods=['POST'])
def upload_audio():
    """Menerima file audio dari form upload, proses, simpan hasil."""
    if 'audio' not in request.files:
        return jsonify({'error': 'Tidak ada file audio'}), 400

    file = request.files['audio']

    if file.filename == '':
        return jsonify({'error': 'Tidak ada file yang dipilih. Silakan pilih file audio.'}), 400

    ext = get_audio_extension(file.filename, file.mimetype)
    if not ext:
        return jsonify({'error': 'Format file tidak didukung. Gunakan .wav, .mp3, .webm, .m4a, atau .ogg.'}), 400

    safe_name = secure_filename(os.path.splitext(file.filename)[0]) or 'audio'
    filename = f"{safe_name}{ext}"
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    file.save(filepath)

    try:
        hasil, confidence = predict_voice(filepath)
    except Exception as e:
        if os.path.exists(filepath):
            os.remove(filepath)
        return jsonify({'error': f'Gagal menganalisis file audio: {str(e)}'}), 400

    simpan_history(filename, hasil, confidence)

    return jsonify({'filename': filename, 'hasil': hasil, 'confidence': confidence})


@app.route('/record', methods=['POST'])
def record_audio():
    """Menerima audio hasil rekaman dari browser (via JS MediaRecorder)."""
    if 'audio' not in request.files:
        return jsonify({'error': 'Tidak ada data audio yang diterima dari browser.'}), 400

    file = request.files['audio']
    if file.filename == '':
        return jsonify({'error': 'Rekaman kosong. Silakan tekan Record lagi.'}), 400

    ext = get_audio_extension(file.filename, file.mimetype)
    if not ext:
        return jsonify({'error': 'Format rekaman tidak didukung. Coba rekam lagi dalam format audio browser yang umum.'}), 400

    filename = f"record_{datetime.now().strftime('%Y%m%d%H%M%S')}{ext}"
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    file.save(filepath)

    try:
        hasil, confidence = predict_voice(filepath)
    except Exception as e:
        if os.path.exists(filepath):
            os.remove(filepath)
        return jsonify({'error': f'Gagal menganalisis rekaman suara: {str(e)}'}), 400

    simpan_history(filename, hasil, confidence)

    return jsonify({'filename': filename, 'hasil': hasil, 'confidence': confidence})


init_db()

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 8000))
    app.run(debug=True, host='0.0.0.0', port=port)
