# model.py
# ==========================================
# Modul AI VOICIN
# Ekstraksi fitur MFCC (Librosa) + Prediksi (Scikit-learn)
# ==========================================

import librosa
import numpy as np
import os
from sklearn.ensemble import RandomForestClassifier
import joblib

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(BASE_DIR, 'voice_model.pkl')

# ------------------------------------------
# EKSTRAKSI FITUR AUDIO (MFCC)
# ------------------------------------------
def extract_features(filepath, n_mfcc=40):
    """
    Membaca file audio, lalu mengekstrak fitur MFCC.
    MFCC (Mel-Frequency Cepstral Coefficients) merepresentasikan
    karakteristik suara manusia dalam bentuk angka.
    Return: array 1D berisi rata-rata tiap koefisien MFCC.
    """
    # sr=22050 -> sample rate standar, mono -> 1 channel
    y, sr = librosa.load(filepath, sr=22050, mono=True)

    # Ekstrak MFCC
    mfcc = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=n_mfcc)

    # Ambil rata-rata tiap koefisien sepanjang waktu
    # agar hasilnya 1 angka per koefisien (bukan matrix)
    mfcc_mean = np.mean(mfcc.T, axis=0)

    return mfcc_mean


# ------------------------------------------
# BUAT & LATIH MODEL DUMMY (SEMENTARA)
# ------------------------------------------
def train_dummy_model(n_mfcc=40):
    """
    Melatih model sederhana dengan DATA SINTETIS/DUMMY.
    Tujuannya HANYA agar aplikasi bisa berjalan end-to-end.

    Konsep dummy:
    - Suara "Original" -> nilai MFCC cenderung punya variasi/noise alami (acak normal)
    - Suara "AI Generated" -> nilai MFCC cenderung lebih 'halus'/konsisten (variasi lebih kecil)

    Nanti bagian ini WAJIB diganti dengan training menggunakan
    dataset asli (contoh: dataset ASVspoof) agar akurasi sesungguhnya.
    """
    np.random.seed(42)
    n_samples = 200  # 100 data "original", 100 data "AI"

    # Data dummy kelas "Original Voice" (label 0)
    original_data = np.random.normal(loc=0, scale=1.5, size=(n_samples // 2, n_mfcc))

    # Data dummy kelas "AI Generated Voice" (label 1)
    ai_data = np.random.normal(loc=1.5, scale=0.7, size=(n_samples // 2, n_mfcc))

    X = np.vstack([original_data, ai_data])
    y = np.array([0] * (n_samples // 2) + [1] * (n_samples // 2))

    # Model sederhana: Random Forest (cukup akurat & tidak perlu tuning rumit)
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X, y)

    # Simpan model ke file, supaya tidak perlu training ulang setiap run
    joblib.dump(model, MODEL_PATH)
    return model


# ------------------------------------------
# LOAD MODEL (atau buat baru jika belum ada)
# ------------------------------------------
def load_model():
    if os.path.exists(MODEL_PATH):
        model = joblib.load(MODEL_PATH)
    else:
        model = train_dummy_model()
    return model


# ------------------------------------------
# FUNGSI UTAMA: PREDIKSI SUARA
# ------------------------------------------
def predict_voice(filepath):
    """
    Fungsi ini dipanggil dari app.py.
    Input: path file audio
    Output: (hasil_label, confidence_score)
    """
    model = load_model()

    # Ekstraksi fitur MFCC dari file audio
    features = extract_features(filepath)
    features = features.reshape(1, -1)  # ubah jadi 2D (1 baris)

    # Prediksi label (0 = Original, 1 = AI)
    prediction = model.predict(features)[0]

    # Ambil probabilitas untuk confidence score
    probabilities = model.predict_proba(features)[0]
    confidence = round(max(probabilities) * 100, 2)

    hasil = "Original Voice" if prediction == 0 else "AI Generated Voice"

    return hasil, confidence


# Tambahan agar import tetap aman saat modul Python dipanggil
__all__ = ["predict_voice", "extract_features", "train_dummy_model", "load_model"]