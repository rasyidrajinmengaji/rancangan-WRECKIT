# VOICIN — AI Voice Detection System

Deteksi suara AI-generated vs suara asli manusia, lewat record langsung di browser atau upload file audio.

## Jalankan (3 langkah, ±1 menit)

```bash
pip install -r requirements.txt
python app.py
```

Buka `http://localhost:8000` di browser.

## Struktur

- `app.py` — Flask app: routing halaman, upload/record, riwayat deteksi
- `model.py` — ekstraksi fitur audio (MFCC) + model klasifikasi
- `templates/`, `static/` — tampilan web (jangan diubah)
- `uploads/` — file audio yang diunggah/direkam user (auto-dibuat, kosong di repo)
- `database.db` — dibuat otomatis saat pertama kali run (riwayat deteksi)

## Catatan

Model saat ini dilatih dengan data sintetis/dummy (`train_dummy_model()` di `model.py`) supaya aplikasi bisa langsung jalan end-to-end. Untuk akurasi deteksi yang sesungguhnya, model perlu dilatih ulang dengan dataset suara asli.
