import unittest
import os

from app import get_audio_extension
from model import predict_voice


class AudioExtensionTests(unittest.TestCase):
    def test_webm_recording_extension_is_supported(self):
        self.assertEqual(get_audio_extension('recording.webm', 'audio/webm'), '.webm')

    def test_unsupported_extension_is_rejected(self):
        self.assertIsNone(get_audio_extension('recording.exe', 'application/x-msdownload'))


class ModelPredictionTests(unittest.TestCase):
    def test_predict_voice_raises_exception_for_non_existent_file(self):
        with self.assertRaises(Exception):
            predict_voice("non_existent_file_path_12345.wav")


if __name__ == '__main__':
    unittest.main()
