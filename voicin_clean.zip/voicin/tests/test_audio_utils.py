import unittest

from app import get_audio_extension


class AudioExtensionTests(unittest.TestCase):
    def test_webm_recording_extension_is_supported(self):
        self.assertEqual(get_audio_extension('recording.webm', 'audio/webm'), '.webm')

    def test_unsupported_extension_is_rejected(self):
        self.assertIsNone(get_audio_extension('recording.exe', 'application/x-msdownload'))


if __name__ == '__main__':
    unittest.main()
